exports.provider = "smtp"; // provider name : gmail, smtp, sendmail
// mail configuration for gmail or smtp
exports.hostName = "mail.webamplifierapps.com";
exports.port = 587;
exports.isSecure = false; // true for 465, false for other ports
exports.username = "support@webamplifierapps.com";
exports.password = "F%+103w3GS3I";
exports.fromEmail = "support@admerkcorp.com";