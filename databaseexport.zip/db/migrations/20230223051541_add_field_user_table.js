/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function (knex) {
    return knex.schema.table("users", function (table) {
        table.integer("email_verified").defaultTo(2).comment("1=yes,2=no")
        table.string("email_code").defaultTo("")
    })
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function (knex) {

};
